export const BIRTH_DATE = "1994-05-15";

/**
 * Calculates current age from a birth date string (YYYY-MM-DD).
 * Accurately takes elapsed months and days into account.
 */
export function calculateAge(birthDateString: string): number {
  const today = new Date();
  const [yearStr, monthStr, dayStr] = birthDateString.split('-');
  const birthYear = parseInt(yearStr, 10);
  const birthMonth = parseInt(monthStr, 10) - 1;
  const birthDay = parseInt(dayStr, 10);

  const birthDate = (!isNaN(birthYear) && !isNaN(birthMonth) && !isNaN(birthDay))
    ? new Date(birthYear, birthMonth, birthDay)
    : new Date(birthDateString);

  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();

  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }

  return age;
}

const siteName = "Portfolio";

export interface TranslationSchema {
  siteTitle: string;
  nav: {
    about: string;
    experience: string;
    skills: string;
  };
  hero: {
    name: string;
    title: string;
    birthDate?: string;
    age: string;
    description: string;
  };
  contact: {
    title: string;
    email: string;
    phone: string;
    order: string;
  };
  experience: {
    title: string;
    items: Array<{
      year: string;
      company: string;
      role: string;
      description?: string;
      tasks?: string[];
      hasGallery?: boolean;
      galleryTitle?: string;
      galleryImages?: string[];
    }>;
  };
  skills: {
    title: string;
    categories: Array<{
      name: string;
      items: string[];
    }>;
  };
  themeLabel: string;
  rightsReserved: string;
}

export const translations: TranslationSchema = {
  siteTitle: siteName,
  nav: {
    about: "À propos",
    experience: "Expériences",
    skills: "Compétences",
  },
  hero: {
    name: "Prénom Nom",
    title: "Développeuse Web & Applications",
    birthDate: BIRTH_DATE,
    get age(): string {
      return `${calculateAge(this.birthDate || BIRTH_DATE)} ans`;
    },
    description: "Graphiste et développeuse passionnée avec 5 ans d'expérience dans la création d'identités visuelles et de supports de communication digitale. Spécialisée en branding et design interactif. Cette solide base de compétences est couronnée par un Master en Design Graphique obtenu en 2017, ainsi qu'une Licence en Sciences de la Nature et de la Vie (2012).",
  },
  contact: {
    title: "Informations de contact",
    email: "testEmail@gmail.com",
    phone: "+213 787663356",
    order: "Commandez votre version de ce site web",
  },
  experience: {
    title: "Expériences professionnelles",
    items: [
      {
        year: "2021 - 2023",
        company: "Creative Studio X",
        role: "Lead UI/UX Designer",
        description: "Direction de l'équipe de design dans la création de prototypes haute fidélité et d'interfaces centrées sur l'utilisateur pour des clients internationaux, avec un accent sur l'accessibilité et l'esthétique contemporaine.",
        tasks: [
          "Direction du développement des systèmes de design visuel",
          "Gestion et encadrement d'équipes de design multidisciplinaires",
          "Mise en œuvre des normes d'accessibilité numérique (WCAG)",
          "Collaboration étroite avec les développeurs sur les bibliothèques de composants",
          "Présentation des solutions de design aux parties prenantes internationales"
        ],
        hasGallery: true,
        galleryTitle: "Voir la galerie du projet",
        galleryImages: [
          "https://picsum.photos/seed/design1/1200/800",
          "https://picsum.photos/seed/design2/1200/800",
          "https://picsum.photos/seed/design3/1200/800"
        ]
      },
      {
        year: "2023 - 2024",
        company: "Digital Horizon",
        role: "Développeuse Full Stack",
        description: "Responsable de la conception et du maintien d'architectures web complexes et d'outils internes.",
        tasks: [
          "Architecture de services backend évolutifs avec Node.js",
          "Conception de tableaux de bord front-end réactifs avec React",
          "Optimisation des bases de données et perfectionnement des requêtes",
          "Intégration de la synchronisation de données en temps réel",
          "Mentorat et accompagnement des développeurs juniors selon les standards de code"
        ],
        hasGallery: true,
        galleryTitle: "Galerie de projets",
        galleryImages: [
          "/images/project-1.svg",
          "/images/project-2.svg",
          "/images/project-3.svg"
        ]
      },
      {
        year: "2018 - Présent",
        company: "Freelance",
        role: "Graphiste & Développeuse Web",
        description: "Collaboration avec divers clients pour concevoir des identités de marque et des expériences digitales remarquables.",
      },
    ]
  },
  skills: {
    title: "Compétences",
    categories: [
      { name: "Design", items: ["Branding", "UI/UX Design", "Design Graphique"] },
      { name: "Développement", items: ["Développement Web", "Applications Multiplateformes"] },
    ]
  },
  themeLabel: "Thème",
  rightsReserved: "Tous droits réservés"
};
